﻿CREATE TABLE [dbo].[Ninja]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] NCHAR(15) NULL, 
    [Gold] INT NULL
)
